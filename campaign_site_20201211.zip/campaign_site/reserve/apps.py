from django.apps import AppConfig


class ReserveConfig(AppConfig):
    name = 'reserve'
