class PayloadParamName:
    id = "id"
    result = "result"
    name = "name"
    description = "description"
    is_registered = "is_registered"