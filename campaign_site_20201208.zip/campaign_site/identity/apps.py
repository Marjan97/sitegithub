from django.apps import AppConfig


class IdentityConfig(AppConfig):
    name = 'identity'
