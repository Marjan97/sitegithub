class DevelopmentRuntimeConfig:
    AUTHENTICATION_CLASSES = (
        'rest_framework.authentication.TokenAuthentication',
        'rest_framework.authentication.BasicAuthentication',
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    )
    REST_FRAMEWORK_DEFAULT_PERMISSION_CLASSES = (
        # 'rest_framework.permissions.IsAuthenticated',
        'rest_framework.permissions.AllowAny',
    )

    DEBUG = True
    ALLOWED_HOSTS = [
        '127.0.0.1',
        'localhost',
        '*',

    ]
    #
    MYSQL_DB_URL = "127.0.0.1"
    MYSQL_DB_PORT = 3000
    MYSQL_DB_USERNAME = "root"
    MYSQL_DB_PASSWORD = "M@rjAnMAedeH7677"
    MYSQL_DB_SCHEMA = "campaign_site_20201127"
    EMAIL_HOST_USER = None
    EMAIL_HOST_PASSWORD = None
    EMAIL_BACKEND = None
    EMAIL_HOST = None
    DOMAIN_NAME = None


class RuntimeConfig(DevelopmentRuntimeConfig):
    pass
