from django.apps import AppConfig


class ZarinpalConfig(AppConfig):
    name = 'zarinpal'
